# 窗口查看器 Spy++
------

仿造vs的工具Spy++，写一个能查看窗口类、标题、句柄、进程的工具，查找时能用红色框标出窗口
> * 设计
> * 功能
> * 测试

------
## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/0.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/1.jpg?raw=true)<br>
<br><br><br>

## 功能
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/spy++1.gif?raw=true)<br>
查看窗口有关信息<br>
<br><br><br>

![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/spy++2.gif?raw=true)<br>
隐藏自身<br>
<br><br><br>

## 测试
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/spy++0.gif?raw=true)<br>
<br><br><br>




