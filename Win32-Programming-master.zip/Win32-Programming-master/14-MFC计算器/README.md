![image](https://github.com/luguanxing/LGX-Projects/blob/master/14-MFC%E8%AE%A1%E7%AE%97%E5%99%A8/demo.gif?raw=true)<br>
