# WannaCry界面 	WannaCry UI
------

使用WPF仿造流行勒索病毒WannaCry的界面做个程序
> * 效果


------
## 效果
![image](https://github.com/luguanxing/Win32-Programming/blob/master/30-WannaCry%E7%95%8C%E9%9D%A2/pictures/WannaCry.gif?raw=true)
<br><br><br>

![image](https://github.com/luguanxing/Win32-Programming/blob/master/30-WannaCry%E7%95%8C%E9%9D%A2/pictures/en.jpg?raw=true)
<br><br><br>

![image](https://github.com/luguanxing/Win32-Programming/blob/master/30-WannaCry%E7%95%8C%E9%9D%A2/pictures/cn.jpg?raw=true)
<br><br><br>







