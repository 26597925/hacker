# 文件按键输入器 MfcTyper
------

将文件中的英文、数字、字符读出采用硬件模拟键盘进行敲击，从而制作脚本或将代码移入云平台
> * 效果
> * 设计

------
## 效果
![image](https://github.com/luguanxing/Win32-Programming/blob/master/26-%E6%96%87%E4%BB%B6%E6%8C%89%E9%94%AE%E8%BE%93%E5%85%A5%E5%99%A8/pictures/1.gif?raw=true)<br><br><br>
![image](https://github.com/luguanxing/Win32-Programming/blob/master/26-%E6%96%87%E4%BB%B6%E6%8C%89%E9%94%AE%E8%BE%93%E5%85%A5%E5%99%A8/pictures/2.gif?raw=true)<br><br><br>
![image](https://github.com/luguanxing/Win32-Programming/blob/master/26-%E6%96%87%E4%BB%B6%E6%8C%89%E9%94%AE%E8%BE%93%E5%85%A5%E5%99%A8/pictures/copy.gif?raw=true)<br><br><br>
<br>

## 设计
![image](https://github.com/luguanxing/Win32-Programming/blob/master/26-%E6%96%87%E4%BB%B6%E6%8C%89%E9%94%AE%E8%BE%93%E5%85%A5%E5%99%A8/pictures/class.jpg?raw=true)<br>
MyTyper类的设计<br>
<br><br><br>





