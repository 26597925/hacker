# 驱动加载卸载工具 DriverLoader
------

加载驱动和卸载驱动的功能
> * 效果
> * 设计

------
## 效果
![image](https://github.com/luguanxing/Win32-Programming/blob/master/27-%E9%A9%B1%E5%8A%A8%E5%8A%A0%E8%BD%BD%E5%8D%B8%E8%BD%BD%E5%B7%A5%E5%85%B7/pictures/0.jpg)
<br>加载驱动<br><br>

![image](https://github.com/luguanxing/Win32-Programming/blob/master/27-%E9%A9%B1%E5%8A%A8%E5%8A%A0%E8%BD%BD%E5%8D%B8%E8%BD%BD%E5%B7%A5%E5%85%B7/pictures/1.jpg)
<br>卸载驱动<br><br>

![image](https://github.com/luguanxing/Win32-Programming/blob/master/27-%E9%A9%B1%E5%8A%A8%E5%8A%A0%E8%BD%BD%E5%8D%B8%E8%BD%BD%E5%B7%A5%E5%85%B7/pictures/2.jpg)
<br>多次加载提示错误<br><br>

![image](https://github.com/luguanxing/Win32-Programming/blob/master/27-%E9%A9%B1%E5%8A%A8%E5%8A%A0%E8%BD%BD%E5%8D%B8%E8%BD%BD%E5%B7%A5%E5%85%B7/pictures/3.jpg)
<br>多次卸载提示错误<br><br>

## 设计
![image](https://github.com/luguanxing/Win32-Programming/blob/master/27-%E9%A9%B1%E5%8A%A8%E5%8A%A0%E8%BD%BD%E5%8D%B8%E8%BD%BD%E5%B7%A5%E5%85%B7/pictures/DriverLoader.jpg?raw=true)<br>
<br><br><br>





