# 简单进程控制工具 Taskmgr
------

做一个简单进程控制工具，能几个控制功能
> * 设计
> * 功能
> * 效果

------

## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/1.jpg?raw=true)<br>
<br><br><br>
## 功能
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/fresh.gif?raw=true)<br>
刷新获得当前所有进程<br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/control.gif?raw=true)<br>
冻结或恢复当前选中进程<br><br>
<br><br><br>
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/0.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/1.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/2.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/3.jpg?raw=true)<br>




