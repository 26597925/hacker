
------

# Windows API编程

### API编程:
    开机自动启动、U盘自动复制、键盘记录器、DLL注入、简单HOOKAPI、简单DLL劫持、文件锁、加密文件病毒、自删除程序、获取窗口RGB颜色、互斥体单实例、屏蔽按键、透明度调整助手、套接字编程
    
### MFC编程:
    网页自动刷新器、监视目录更改、内存扫描与修改、进程控制、简易资源管理器、倒计时器、异形窗口、套接字编程、窗口查看器、MFC截屏、文件按键输入器、驱动加载卸载工具、操作MySQL数据库


------

    
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/15-%E7%9B%91%E8%A7%86%E7%9B%AE%E5%BD%95%E6%9B%B4%E6%94%B9/pictures/0.jpg?raw=true)<br>
监视目录更改<br><br><br><br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/18-%E8%BF%9B%E7%A8%8B%E6%8E%A7%E5%88%B6/pictures/3.jpg?raw=true)<br>
进程控制<br><br><br><br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/0.jpg?raw=true)<br>
内存扫描与修改<br><br><br><br><br>
 ![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/20-%E7%AE%80%E6%98%93%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8/pictures/1.jpg?raw=true)<br>
简易资源管理器<br><br><br><br><br>   
 ![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/21-%E5%80%92%E8%AE%A1%E6%97%B6%E5%99%A8/pictures/1.jpg?raw=true)<br>
倒计时器<br><br><br><br><br>     
 ![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/22-%E5%BC%82%E5%BD%A2%E7%AA%97%E5%8F%A3/pictures/1.gif?raw=true)<br>
异形窗口<br><br><br><br><br>   
 ![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/24-%E7%AA%97%E5%8F%A3%E6%9F%A5%E7%9C%8B%E5%99%A8/pictures/spy++1.gif?raw=true)<br>
窗口查看器<br><br><br><br><br>   
 ![image](https://github.com/luguanxing/Windows-C-Projects/raw/master/25-MFC%E6%88%AA%E5%B1%8F/pictures/screenshot.gif?raw=true)<br>
MFC截屏<br><br><br><br><br>   
 ![image](https://github.com/luguanxing/Win32-Programming/raw/master/26-%E6%96%87%E4%BB%B6%E6%8C%89%E9%94%AE%E8%BE%93%E5%85%A5%E5%99%A8/pictures/2.gif?raw=true)<br>
文件按键输入器<br><br><br><br><br> 
 ![image](https://github.com/luguanxing/Win32-Programming/raw/master/29-%E9%9A%90%E8%97%8F%E7%9B%98%E7%AC%A6/pictures/DiskHider.gif?raw=true)<br>
隐藏盘符<br><br><br><br><br> 
