# MFC截屏 MFCScreenShot
------

采用面对对象的方法，仿造QQ的截图工具，写一个能保存鼠标拖动，用红色标记所圈出区域的截图软件
> * 效果
> * 设计
> * 测试

------
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/25-MFC%E6%88%AA%E5%B1%8F/pictures/screenshot.gif?raw=true)<br>
<br><br><br>

## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/25-MFC%E6%88%AA%E5%B1%8F/pictures/class.jpg?raw=true)<br>
MyScreenShot类的设计，在对话框中进行响应并调用对应的接口<br>
<br><br><br>

## 测试
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/25-MFC%E6%88%AA%E5%B1%8F/pictures/0.png?raw=true)<br>
<br><br><br>




