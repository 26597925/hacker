# 简单扫描与修改内存 Simple Cheat Engine
------

做一个内存扫描修改工具
> * 设计
> * 功能
> * 效果

------

## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/0.jpg?raw=true)<br>
<br><br><br>
## 功能
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/getprocess.gif?raw=true)<br>
刷新获得当前所有进程<br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/search+modify.gif?raw=true)<br>
搜索和修改进程中指定内存数据<br><br>
<br><br><br>
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/1.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/19-%E7%AE%80%E5%8D%95%E6%89%AB%E6%8F%8F%E4%B8%8E%E4%BF%AE%E6%94%B9%E5%86%85%E5%AD%98/pictures/2.jpg?raw=true)<br>




