# 文件目录监视器
------

做一个目录监视工具，能监视选择目录下的所有文件更改
> * 功能
> * 设计
> * 效果

------

## 功能
监视选择目录文件变化，导出txt文件
## 设计
![image](https://github.com/luguanxing/LGX-Projects/blob/master/15-%E7%9B%91%E8%A7%86%E7%9B%AE%E5%BD%95%E6%9B%B4%E6%94%B9/pictures/0.jpg?raw=true)<br>
<br><br><br>
## 导出
![image](https://github.com/luguanxing/LGX-Projects/blob/master/15-%E7%9B%91%E8%A7%86%E7%9B%AE%E5%BD%95%E6%9B%B4%E6%94%B9/pictures/1.jpg?raw=true)<br>
![image](https://github.com/luguanxing/LGX-Projects/blob/master/15-%E7%9B%91%E8%A7%86%E7%9B%AE%E5%BD%95%E6%9B%B4%E6%94%B9/pictures/2.jpg?raw=true)<br>

