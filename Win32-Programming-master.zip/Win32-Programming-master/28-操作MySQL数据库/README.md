# 操作MySQL数据库 TestSQL
------

MFC执行MySQL语句并查看效果
> * 效果
> * 过程

------
## 效果
![image](https://github.com/luguanxing/Win32-Programming/blob/master/28-%E6%93%8D%E4%BD%9CMySQL%E6%95%B0%E6%8D%AE%E5%BA%93/pictures/0.gif?raw=true)
<br>执行MySQL语句<br><br>
<br><br>

## 过程

### 1.添加包含目录
\MySQL Server 5.7\include;

### 2.添加引用目录和库目录
\MySQL Server 5.7\lib;

### 3.链接器附加依赖项
libmysql.lib

### 4.将libmysql.lib和libmysql.dll复制到工程目录(区分32/64位)
<br>

### 5.添加头文件mysql.h
<br>




