# U盘收割机V2.0/USB-HarvesterII

------

> * 使用Windows API函数自动检测U盘并获得其中文件<br>Using Windows API function to check and get files from USB automatically.

------

	
## 流程图/Flow Chart：<br>
![image](https://github.com/luguanxing/LGX-Projects/blob/master/02-U%E7%9B%98%E8%87%AA%E5%8A%A8%E5%A4%8D%E5%88%B6/U%E7%9B%98%E6%94%B6%E5%89%B2%E6%9C%BAV2.0/%E6%B5%81%E7%A8%8B%E5%9B%BE.jpg?raw=true)<br>


<br>
## 收割机V2.0<br>
优点：可同时复制多个USB，持久运行<br>
缺点：<br>



