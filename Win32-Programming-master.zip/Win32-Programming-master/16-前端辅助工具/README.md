# 前端辅助工具
------

做一个辅助工具，能集成几个写前端常用的功能
> * 背景
> * 功能
> * 设计
> * 效果

------

## 背景
集成之前API的练习与学习MFC可视化操作
## 功能
自动取色，可调不同窗体透明度（互不影响），自动检测前端目录更新并自动刷新浏览器
## 设计
![image](https://github.com/luguanxing/LGX-Projects/blob/master/16-%E5%89%8D%E7%AB%AF%E8%BE%85%E5%8A%A9%E5%B7%A5%E5%85%B7/pictures/1.jpg?raw=true)<br>
(注：仅支持chrome浏览器刷新，可同时编辑html,css,javascript代码)
<br><br><br>
## 效果
![image](https://github.com/luguanxing/LGX-Projects/blob/master/16-%E5%89%8D%E7%AB%AF%E8%BE%85%E5%8A%A9%E5%B7%A5%E5%85%B7/pictures/2.jpg?raw=true)<br>

