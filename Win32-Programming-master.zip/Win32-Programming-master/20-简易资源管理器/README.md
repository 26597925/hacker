# 资源管理器 Simple Explorer
------

做一个简易资源管理器，能查看和打开文件
> * 设计
> * 功能
> * 效果

------

## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/20-%E7%AE%80%E6%98%93%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8/pictures/1.jpg?raw=true)<br>
<br><br><br>
## 功能
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/20-%E7%AE%80%E6%98%93%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8/pictures/treectrl.gif?raw=true)<br>
用树形分支展开文件夹，单击时将文件夹中的文件显示出来<br><br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/20-%E7%AE%80%E6%98%93%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8/pictures/listctrl.gif?raw=true)<br>
能双击打开显示的文件<br><br>
<br><br><br>
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/20-%E7%AE%80%E6%98%93%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8/pictures/0.jpg?raw=true)<br>



