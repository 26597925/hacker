# 隐藏盘符 	DiskHider
------

隐藏盘符并恢复
> * 效果


------
## 效果
![image](https://github.com/luguanxing/Win32-Programming/blob/master/29-%E9%9A%90%E8%97%8F%E7%9B%98%E7%AC%A6/pictures/DiskHider.gif?raw=true)
<br>使盘符成功隐藏







