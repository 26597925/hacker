# 倒计时器 CountDownTimer
------

用线程协调自定义消息和绘图做个简单倒计时器
> * 设计
> * 效果

------
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/21-%E5%80%92%E8%AE%A1%E6%97%B6%E5%99%A8/pictures/countdowntimer.gif?raw=true)<br>
<br><br><br>
## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/21-%E5%80%92%E8%AE%A1%E6%97%B6%E5%99%A8/pictures/0.jpg?raw=true)<br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/21-%E5%80%92%E8%AE%A1%E6%97%B6%E5%99%A8/pictures/1.jpg?raw=true)<br>
<br><br><br>



