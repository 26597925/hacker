# 异形窗口 AbnormalWindow
------

仿造SOJ网页做一个异形窗口
> * 设计
> * 效果

------
## 效果
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/22-%E5%BC%82%E5%BD%A2%E7%AA%97%E5%8F%A3/pictures/soj.gif?raw=true)<br>
<br><br><br>
## 设计
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/22-%E5%BC%82%E5%BD%A2%E7%AA%97%E5%8F%A3/pictures/0.jpg?raw=true)<br>
原网页版<br><br><br>
![image](https://github.com/luguanxing/Windows-C-Projects/blob/master/22-%E5%BC%82%E5%BD%A2%E7%AA%97%E5%8F%A3/pictures/1.gif?raw=true)<br>
桌面端山寨版<br><br><br>



